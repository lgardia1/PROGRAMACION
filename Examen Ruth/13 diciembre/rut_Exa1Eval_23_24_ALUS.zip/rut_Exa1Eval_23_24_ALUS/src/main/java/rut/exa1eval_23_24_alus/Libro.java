/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exa1eval_23_24_alus;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 *
 * @author Rut
 */
enum Idioma {
    ALEMÁN, INGLÉS, FRANCÉS, ESPAÑOL, ITALIANO, ÁRABE, CHINO, URDU, PORTUGUÉS,
    RUSO, HINDI, OTHER
}

public class Libro {

    private String titulo;
    private String autor;
    private String isbn;
    private LocalDate fecha;
    private Idioma[] idiomas;

    
    
    public Libro(String titulo, String autor, String isbn, String fecha,
            String[] lenguas) {
        this.titulo = titulo;
        this.autor = autor;
        setIsbn(isbn);
        setFecha(fecha);
        setIdiomas(lenguas);
    }
 

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
    
    public LocalDate getFecha() {
        return fecha;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        if (isbnValido(isbn)) {
            this.isbn = isbn;
        } else {
            this.isbn = "978-PA-12345-67-X";
        }
    }

// Ejercicio 1: El ISBN siempre estará formado por el prefijo 978-país-editorial-publicación-dc
// De estas 5 partes sólo el prefijo 978 y el dígito de control tienen un número 
// fijo de dígitos (4 en total). Los otros grupos tienen un número variable
// de dígitos pero lo que importa es que entre todos ellos debe haber exactamente
// 9 dígitos. Así el ISBN13 siempre está formado por 13 dígitos.
    
    // 1,5 ptos
//    función isbnValido


    // Función auxiliar para trabajar en isbnValido
    public boolean isNumeric(String cad) {
        try {
            Integer.parseInt(cad);
        } catch (NumberFormatException error) {
            return false;
        }
        return true;
    }

    

    // Ejercicio 2: convertir el String fecha en una fecha válida 
    // El String tiene que tener la forma "dd-mm-yyyy" 
    // Si no se puede convertir, se pondrá la mínima fecha posible 
    // proporcionada por Java
    
    // 2 ptos
//    función setFecha


    public Idioma[] getIdiomas() {
        return idiomas;
    }

    // Ejercicio 3:Convertir el array de String a un array Idioma 
    // (lo usa en el constructor)
    // 1,7 ptos
//    función setIdiomas
       

    // Convierte la fecha inglesa a fecha española en forma de String
    // (lo usa el toString) 
    // 0,9 ptos
//   función convierteFechaASp
    
    // Convierte el array de idiomas a un String
    // (lo usa el toString)
    // 1,3 ptos
//    función getIdiomasString 
    
    
    // Ejercicio 4: Mostrar los atributos de Libro de la siguiente forma
    // 0,3 + 1,3(getIdiomasString) + 0,9(convierteFechaASp) = 2,5 ptos
    @Override
    public String toString() {
        
        
    }

}
